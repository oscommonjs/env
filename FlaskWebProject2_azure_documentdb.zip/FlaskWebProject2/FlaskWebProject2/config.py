CSRF_ENABLED = True
SECRET_KEY = 'you-will-never-guess'

DOCUMENTDB_HOST = 'https://abd.documents.azure.com:443/'
DOCUMENTDB_KEY = 'sWTABtFM39fRFvpXXOSNVVpxuNCBVSkpgQ1jQIOvWbY4UL11VxKspxIsKuu0YtLV2a14ZoyVhWZ9ArGjYd4Lnw=='

DOCUMENTDB_DATABASE = 'exploitkit'
DOCUMENTDB_COLLECTION = 'exploits'
DOCUMENTDB_DOCUMENT = 'document'
