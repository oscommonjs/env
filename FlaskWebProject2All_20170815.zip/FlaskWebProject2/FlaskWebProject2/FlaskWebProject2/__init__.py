"""
The flask application package.
"""

from flask import Flask
app = Flask(__name__)
app.config.from_object('config')
import FlaskWebProject2.views
#from flask_cloudy import Storage
#import libcloud.security
#libcloud.security.VERIFY_SSL_CERT = False

# Setup storage
#storage = Storage()
#storage.init_app(app) 