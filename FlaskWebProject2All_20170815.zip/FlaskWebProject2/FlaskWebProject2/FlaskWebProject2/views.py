"""
Routes and views for the flask application.
"""

from datetime import datetime,timedelta
from flask import render_template,redirect,request,url_for
from FlaskWebProject2 import app
from forms import VoteForm
from forms import CloudStorageURLSigner
import config
import pydocumentdb.document_client as document_client
import base64,hmac,hashlib,urllib,time,md5,sys
from werkzeug import secure_filename
from azure.storage import AccessPolicy
from azure.storage.blob import BlockBlobService,ContentSettings, ContainerPermissions
import string, random, requests, os

from flask_cloudy import Storage
import libcloud.security
libcloud.security.VERIFY_SSL_CERT = False

import Crypto.Hash.SHA256 as SHA256
import Crypto.PublicKey.RSA as RSA
import Crypto.Signature.PKCS1_v1_5 as PKCS1_v1_5

#LOCAL#S3#S3_US_WEST#S3_US_WEST_OREGON#S3_EU_WEST#S3_AP_SOUTHEAST
#S3_AP_NORTHEAST#GOOGLE_STORAGE#AZURE_BLOBS#CLOUDFILES

# Update the config 
app.config.update({
	#"STORAGE_PROVIDER": "S3", # Can also be S3, GOOGLE_STORAGE, etc... 
	#"STORAGE_KEY": "AKIAJTHVKDTK73SEUAHQ",
	#"STORAGE_SECRET": "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",
	#"STORAGE_CONTAINER": "flask123",  # a directory path for local, bucket name of cloud
	#"STORAGE_SERVER": True

 #   "STORAGE_PROVIDER": "AZURE_BLOBS", # Can also be S3, GOOGLE_STORAGE, etc... 
	#"STORAGE_KEY": "cs22594089197e9x4607x85c",
	#"STORAGE_SECRET": "6Eu9bQpbX2OeCz1HG6xqwsslHtDu1xwOM1tAOgUwiWziBF2DwZGuQc5c9klF440Ow2NJdUpcEhUyTQKXl5gGKg==",
	#"STORAGE_CONTAINER": "flask",  # a directory path for local, bucket name of cloud
	#"STORAGE_SERVER": True

 #   "STORAGE_PROVIDER": "GOOGLE_STORAGE", # Can also be S3, GOOGLE_STORAGE, etc... 
	#"STORAGE_KEY": "938498535906-compute@developer.gserviceaccount.com",
	#"STORAGE_SECRET": "key.pem",
	#"STORAGE_CONTAINER": "cdngl",  # a directory path for local, bucket name of cloud
	#"STORAGE_SERVER": True

    "STORAGE_PROVIDER": "GOOGLE_STORAGE", # Can also be S3, GOOGLE_STORAGE, etc... 
	"STORAGE_KEY": "GOOGSQQGY7CLTJI74CGO",
	"STORAGE_SECRET": "nYSOoOOvpoHtQC0hurOtXqTcCyK5jHMH9MYklEfN",
	"STORAGE_CONTAINER": "cdngl",  # a directory path for local, bucket name of cloud
	"STORAGE_SERVER": True
	#"STORAGE_SERVER_URL": "/files" # The url endpoint to access files on LOCAL provider
})

# Setup storage
storage = Storage()
storage.init_app(app) 

#My API
S3PROXY_AWS_ACCESS_KEY = 'AKIAJTHVKDTK73SEUAHQ'
S3PROXY_AWS_SECRET_KEY = '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'

# The name of the new Shared Access policy
policy_name = 'readandlistonly'
# The Storage Account Name
storage_account_name = 'cs22594089197e9x4607x85c'
storage_account_key = '6Eu9bQpbX2OeCz1HG6xqwsslHtDu1xwOM1tAOgUwiWziBF2DwZGuQc5c9klF440Ow2NJdUpcEhUyTQKXl5gGKg=='
#storage_container_name = 'flask'
#example_file_path = '..\\sampledata\\sample.log'
#policy_name = 'mysaspolicy2'

blob_service = BlockBlobService(account_name=storage_account_name, account_key=storage_account_key)

# The Google Cloud Storage API endpoint. You should not need to change this.
GCS_API_ENDPOINT = 'https://storage.googleapis.com'
SERVICE_ACCOUNT_EMAIL = '938498535906-compute@developer.gserviceaccount.com'
key64 = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDESsMnj1yrnC+30N0UoY7P4nlMueaFS02eiS2lsTOhvIHNncML0YUSbDLDicvh2PFtgPBVwMEQetVzZjlhTapGUdjK+0gBlzUZIuH8ZxkZdmk5bGHcHPQE8dIreAIonpt4LhJt+AV5pRbuSFH0gBDPQyWCBPMbLHfP2NbsLYPlBxyg+xcaSfG06I1+tFTEu15eULHfkNon178bcl/cftyZEA0OvjlgH87Q+UWjJvVh8UZwm72986g+Ln62pN6Mtdb5WK3BenC/TRcGWKZ5A9IuDJwO+yaGzLsqBK4teOvqaymHp6C6OqSYF2B2DVOeyYJVzdVy2aBLAZKxpIYdL4MZAgMBAAECggEAHdtjWNKZHW9J4NNPtXInh15i5fVG55J/MXSbMV9FQ74pHk33W4ZYj+dOR2jfzrARdP8OT3TcyPVuHzn202KdWknbyHA1USyfQn4IUryZ2EInGjlunyz2PwRLXBpKdcQ+UKbtXbXCm3CtjrwIX0DVjbkgbOj003bNmJtagZ0guUa569+nYvUlJ2SKWVmdHeYUsRdJx+t0p7s0nX6c9TT/pcxKVDEViJnep3HSee6w26Dk/CaRG2oLlmtfEzVeUK7bVpuaTw6ffww5Oqfj4pyVSfGl+xs2GMPgCTF6cRkjxzkeaEzWr9tcNUBwZ5EV66EFAwM1U6fkl4eaayFeY15ZmwKBgQDn0IScz6nJMXVCxQn2yUM7nlE9gPA4ybaWKu5xkAl8bQF5q6qXCNTBpFl/AXmrtBs2ezfAtr6FUmb5aNyEGX6X5Q2bBI/BhTIkNQMqX6Kx5cf+gxOckLcx35i5+vHhdiVVO0oLqwCpJs/atN89VCJM2MUwSaFnWI4uA4g93MfBbwKBgQDYxXt3SLLgc7CtBY2x+/O/l3YKFXtxRoG2EFC2JuoFo6rT77ho6eu0X+JAwCFRyTfnVIl2iazpfJG+vLMqfVr3zYfzr4ahXiSLyf+8NiFF6r1lBC0NR/fn2JPyy7mLpTxtPjI7teuDNupwJNxVECQKR4wzHZswtJssoCVB2dev9wKBgCX3wyCj6p0nWptbBmzDPh3PqmK2caH7d8pUscUr4EHe4LT65u/h5Gbq8jWZGkKDN0nPGKyZwc64VmFXSXbhbhiWzYmsT5dUp4fCnwgbrdwRVJZdBaNJGJg0lSEw9tkErsys703F7k/GKZkass2qsAuCHZnxFVyF5pOmxHPNa3JFAoGBAJytuHzSPgA/fn7AmdcAfgCIMBg/yLZqOMzoY/4UiGfFEW8YQJkMIoKAH1+fvzWHE/IPR0A3aJRmpk1PxMw8SOj9VHuM7elqy02ClmZqVYhcj8IYz5te3k9kWiNOnvDRYKixIMvJxM1VfwPJkLum6/XGGw7DIm2EzPfnVKaRFvWnAoGBAK5VVEP7PNaTGK3+ICVR4MPVLFS7CTvR0aSXz1o1FUw48+VKNtgttrWw1JchwM8nJFey9OkPhY4rP1MsydLPddEbYZSKzVreuc1VhuNox3UsS+vX5ZZVtsZc9/ptNYbdpM6SNSkUoADOjxiq0x0BFxHS10eGTrcYixnuSnGexVyw"



@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )

@app.route('/contact')
def contact():
    """Renders the contact page."""
    return render_template(
        'contact.html',
        title='Contact',
        year=datetime.now().year,
        message='Your contact page.'
    )

@app.route('/about')
def about():
    """Renders the about page."""
    return render_template(
        'about.html',
        title='About',
        year=datetime.now().year,
        message='Your application description page.'
    )

@app.route('/create')
def create():
    """Renders the contact page."""
    client = document_client.DocumentClient(config.DOCUMENTDB_HOST, {'masterKey': config.DOCUMENTDB_KEY})

    # Attempt to delete the database.  This allows this to be used to recreate as well as create
    try:
        db = next((data for data in client.ReadDatabases() if data['id'] == config.DOCUMENTDB_DATABASE))
        client.DeleteDatabase(db['_self'])
    except:
        pass

    # Create database
    db = client.CreateDatabase({ 'id': config.DOCUMENTDB_DATABASE })

    # Create collection
    collection = client.CreateCollection(db['_self'],{ 'id': config.DOCUMENTDB_COLLECTION })

    # Create document
    document = client.CreateDocument(collection['_self'],
        { 'id': config.DOCUMENTDB_DOCUMENT,
          'Web Site': 0,
          'Cloud Service': 0,
          'Virtual Machine': 0,
          'name': config.DOCUMENTDB_DOCUMENT 
        })

    return render_template(
       'create.html',
        title='Create Page',
        year=datetime.now().year,
        message='You just created a new database, collection, and document.  Your old votes have been deleted')

@app.route('/vote', methods=['GET', 'POST'])
def vote(): 
    form = VoteForm()
    replaced_document ={}
    if form.validate_on_submit(): # is user submitted vote  
        client = document_client.DocumentClient(config.DOCUMENTDB_HOST, {'masterKey': config.DOCUMENTDB_KEY})

        # Read databases and take first since id should not be duplicated.
        db = next((data for data in client.ReadDatabases() if data['id'] == config.DOCUMENTDB_DATABASE))

        # Read collections and take first since id should not be duplicated.
        coll = next((coll for coll in client.ReadCollections(db['_self']) if coll['id'] == config.DOCUMENTDB_COLLECTION))

        # Read documents and take first since id should not be duplicated.
        doc = next((doc for doc in client.ReadDocuments(coll['_self']) if doc['id'] == config.DOCUMENTDB_DOCUMENT))

        # Take the data from the deploy_preference and increment our database
        doc[form.deploy_preference.data] = doc[form.deploy_preference.data] + 1
        replaced_document = client.ReplaceDocument(doc['_self'], doc)

        # Create a model to pass to results.html
        class VoteObject:
            choices = dict()
            total_votes = 0

        vote_object = VoteObject()
        vote_object.choices = {
            "Web Site" : doc['Web Site'],
            "Cloud Service" : doc['Cloud Service'],
            "Virtual Machine" : doc['Virtual Machine']
        }
        vote_object.total_votes = sum(vote_object.choices.values())

        return render_template(
            'results.html', 
            year=datetime.now().year, 
            vote_object = vote_object)

    else :
        return render_template(
            'vote.html', 
            title = 'Vote',
            year=datetime.now().year,
            form = form)

@app.route("/upload", methods=["POST", "GET"])
def upload():
    if request.method == "POST":
        file = request.files.get("file")
        print file
        my_upload = storage.upload(file)
        # some useful properties
        name = my_upload.name
        extension = my_upload.extension
        size = my_upload.size
        url = my_upload.url  
        return url
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form action="/upload" method=post enctype=multipart/form-data>
      <p><input type=file name=file>
         <input type=submit value=Upload>
    </form>
    '''    
 #Pretending the file uploaded is "my-picture.jpg"    
 #it will return a url in the format: http://domain.com/files/my-picture.jpg
 #A download endpoint, to download the file
@app.route("/download/<path:object_name>")
def download(object_name):
    print "fucking download"
    my_object = storage.get(object_name)
    url = my_object.download_url(180)
    return url
    #else:
    #    """Renders the home page."""
    #    return render_template(
    #        'index.html',
    #        title='Home Page',
    #        year=datetime.now().year,
    #    )

@app.route('/amazons3sign/<path:path>')
def transform_path(path):
    print "\n\n\n***Generating the encoded url"
    try:
        bucket, file_path = _splitPaths(path)
        expire = int(request.args.get('expire', '60'))
        print "Expiring after {expire}".format(expire=expire)
        expiration = _calculate_expiration(expire)
        return _calculate(bucket, file_path, expiration)
    except AttributeError:
        return "The path is not long enough, did we miss the bucket?"


def _splitPaths(path):
    paths = path.split("/")
    if len(paths) < 2:
        raise AttributeError

    bucket = paths[0]
    paths.remove(bucket)
    file_path = '/'.join(paths)

    return bucket, file_path


def _calculate_expiration(expire, current_time=-1):
    if current_time == -1:
        current_time = int(time.time())
    expiration = current_time + expire
    print "Expiring after {expiration}, calculated from {current_time} and {expire}"\
        .format(expiration=expiration, current_time=current_time, expire=expire)
    return expiration


def _calculate(bucket, file_path, expiration):
    url = "GET\n\n\n{expiration}\n/{bucket}/{file_path}".format(expiration=str(expiration), bucket=bucket, file_path=file_path)
    print "Generated {url} from {expiration} and {file_path}".format(url=url, expiration=expiration, file_path=file_path)
    print "Encoding url with {S3PROXY_AWS_SECRET_KEY}".format(S3PROXY_AWS_SECRET_KEY=S3PROXY_AWS_SECRET_KEY)
    h = hmac.new(S3PROXY_AWS_SECRET_KEY, url, hashlib.sha1)
    signature = urllib.quote_plus(base64.encodestring(h.digest()).strip())
    s3_url = "https://{bucket}.s3.amazonaws.com/{file_path}?AWSAccessKeyId={S3PROXY_AWS_ACCESS_KEY}" \
             "&Expires={expiration}&Signature={signature}"
    return s3_url.format(bucket=bucket, file_path=file_path, S3PROXY_AWS_ACCESS_KEY=S3PROXY_AWS_ACCESS_KEY,
                         expiration=expiration, signature=signature)


@app.route('/blobupload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
    	file = request.files['file']
    	filename = secure_filename(file.filename)
        print filename
    	fileextension = filename.rsplit('.',1)[1]
        print fileextension
        Randomfilename = id_generator()
        filename = Randomfilename + '.' + fileextension
        try:
            blob_service.create_blob_from_stream(storage_container_name, filename, file)
        except Exception:
            print 'Exception=' + Exception 
            pass
        ref =  'http://'+ storage_account_name + '.blob.core.windows.net/' + storage_container_name + '/' + filename
        return '''
	    <!doctype html>
	    <title>File Link</title>
	    <h1>Uploaded File Link</h1>
	    <p>''' + ref + '''</p>
	    <img src="'''+ ref +'''">
	    '''
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form action="" method=post enctype=multipart/form-data>
      <p><input type=file name=file>
         <input type=submit value=Upload>
    </form>
    '''

def id_generator(size=32, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

@app.route('/blobsign/<path:path>')
def blobsign(path):
    # Create the container, if it does not already exist
    #blob_service.create_container(storage_container_name)
    # Upload an example file to the container
    # blob_service.create_blob_from_path(
        # storage_container_name,
        # 'sample.log',
        # example_file_path,
    # )
    bucket, file_path = _splitPaths(path)
    print bucket,file_path
    # Create a new policy that expires after a week
    access_policy = AccessPolicy(permission=ContainerPermissions.READ + ContainerPermissions.LIST, expiry=datetime.utcnow() + timedelta(minutes=1))
    print "fuck222"
    # Get the existing identifiers (policies) for the container
    identifiers = blob_service.get_container_acl(bucket)
    # And add the new one ot the list
    identifiers[policy_name] = access_policy
    # Set the container to the updated list of identifiers (policies)
    blob_service.set_container_acl(bucket,identifiers)
    # Generate a new Shared Access Signature token using the policy (by name)
    sas_token = blob_service.generate_container_shared_access_signature(bucket,id=policy_name)
    blob_url = "https://{storage_account_name}.blob.core.windows.net/{bucket}/{file_path}?{sas_token}"
    return blob_url.format(storage_account_name=storage_account_name, bucket=bucket, file_path=file_path,sas_token=sas_token)

#BUCKET_NAME = 'cdngl'
#OBJECT_NAME = 'cdn.js'
@app.route('/googlestoragesign/<path:path>')
def gc_sign(path):
    print "\n\n\n***Generating the new google encoded url"
    try:
        bucket, file_path = _splitPaths(path)
        print bucket,file_path
        keyDER = base64.b64decode(key64)
        private_key = RSA.importKey(keyDER)
        signer = CloudStorageURLSigner(private_key, SERVICE_ACCOUNT_EMAIL,GCS_API_ENDPOINT)
        file_path = '/%s/%s' % (bucket, file_path)
        r = signer.Get(file_path)
        return r.request.url
    except AttributeError:
        return "The path is not long enough, did we miss the bucket?"



